export const transformData = (response) => {
    return {
        ...response,
        main: {
            ...response.main,
        },
        weather: response.weather.map((weatherItem) => ({
            ...weatherItem,
            description: capitalizeFirstLetter(weatherItem.description),
        })),
        wind: {
            ...response.wind,
            speed: parseFloat(mpsToKph(response.wind.speed).toFixed(2)),
            gust: parseFloat(mpsToKph(response.wind.gust).toFixed(2)),
        },
        sys: {
            ...response.sys,
            sunrise: timestampToTime(response.sys.sunrise, response.timezone),
            sunset: timestampToTime(response.sys.sunset, response.timezone),
        },
    };
};

const mpsToKph = (mps) => mps * 3.6;

const timestampToTime = (timestamp, timezone) => {
    const utcTimestamp = timestamp + timezone;
    const date = new Date(utcTimestamp * 1000);
    return date.toLocaleTimeString('en-EN', {
        hour: '2-digit',
        minute: '2-digit',
        hour12: false,
    });
};

const capitalizeFirstLetter = (string) =>
    string.charAt(0).toUpperCase() + string.slice(1);

/*Function to get forecast per day per hour*/
export const getForecastPerDay = (data) => {
    const forecastsPerDay = {};

    if (data) {
        data.list?.forEach((forecast) => {
            const date = new Date(forecast.dt * 1000).toLocaleDateString('en-CA');
            if (!forecastsPerDay[date]) {
                forecastsPerDay[date] = [];
            }
            forecastsPerDay[date].push(forecast);
        });

        Object.keys(forecastsPerDay).forEach((date) => {
            forecastsPerDay[date].sort((a, b) => a.dt - b.dt);
        });
    }

    return forecastsPerDay;
};

export const getAllCities = (data) => {
    const cities = []

    data.forEach((city) => {
       cities.push(city)
    });

    return Array.from(cities);
};
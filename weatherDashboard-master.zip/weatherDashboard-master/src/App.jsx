import Dashboard from "./components/Dashboard/dashboard";
import { createTheme, ThemeProvider } from '@mui/material/styles';
import Header from "./components/Header/header";
import Footer from "./components/Footer/footer";
import { SearchProvider } from "./SearchProvider";
import { SpeedInsights } from '@vercel/speed-insights/react';
import { Analytics } from "@vercel/analytics/react"

const theme = createTheme({
  colorSchemes: {
    light: {
      background: {
        default: '#8ebee9',
        secondary: '#508fc7',
        hover: '#509de1'
      },
      text: {
        primary: '#222',
        secondary: '#333'
      },
    },
    dark: {
      background: {
        default: '#222',
        secondary: '#373535',
        hover: '#454242'
      },
      text: {
        primary: '#f0f8ff',
        secondary: '#dbdbdb'
      },
    },
  },
  cssVariables: {
    colorSchemeSelector: 'class'
  },
  breakpoints: {
    values: {
      mobile: 0,
      tablet: 768,
      laptop: 1024,
      desktop: 1200,
    },
  },
});

function App() {
  return (
    <SearchProvider>
      <ThemeProvider theme={theme}>
      <Analytics />
        <SpeedInsights />
        <div id="app-container">
          <Header />
          <main>
            <Dashboard />
          </main>
          <Footer />
        </div>
      </ThemeProvider>
    </SearchProvider>
  );
}
export default App;

import Loader from "../Loader/Loader";
import AccordionForecast from "../Accordion/accordion";
import { Box, Typography } from "@mui/material";
import { useForecast } from "../../customHooks";

export const ForecastPanel = ({ city }) => {

    const { forecast, isLoading, isError } = useForecast(city);

    if (isError) { return (<></>); }
    if (isLoading) return <Loader />;

    if (!forecast || Object.keys(forecast).length === 0) {
        return (
            <Box sx={{ width: '80%', margin: 'auto', textAlign: 'center', mt: 2 }}>
                <Typography variant="h6">
                    No forecast data available.
                </Typography>
            </Box>
        );
    }

    return (
        <Box sx={{ width: '80%', margin: 'auto', textAlign: 'center', mt: 2 }}>
            <Typography variant="h4" component="h1" fontWeight={700} sx={{ mb: 2 }}>
                Forecast for next 5 days
            </Typography>
            {Object.entries(forecast).map(([date, forecasts]) => (
                <AccordionForecast key={date} date={date} forecasts={forecasts} />
            ))}
        </Box>
    );
}
import { makeStyles } from "@mui/styles";
import ModeSwitcher from "../ThemeSwitcher/themeSwitcher";
import { Typography } from "@mui/material";

const useStyles = makeStyles((theme) => {
    const currentScheme = theme.colorSchemes[theme.palette.mode];

    return {
        header: {
            backgroundColor: currentScheme.background.secondary,
            color: currentScheme.text.secondary,
            display: 'flex',
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'space-between',
            borderBottom: `1px solid ${currentScheme.text.secondary}`,
            padding: '1rem',
            [theme.breakpoints.down('tablet')]: {
                flexDirection: 'column',
            },
        }
    };
});

export const Header = () => {
    const classes = useStyles();

    return (
        <header className={classes.header}>
            <Typography variant="h1" sx={{ fontSize: '2rem' }} >Weather Dashboard</Typography>
            <ModeSwitcher />
        </header>
    )
}
export default Header;
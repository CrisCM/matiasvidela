import { Box, Typography } from "@mui/material";
import Search from "../Search/search";
import { useEffect, useState } from "react";
import { ForecastPanel } from "../ForecastPanel/forecastPanel";
import WeatherDetails from "../WeatherDetails/weatherDetails";
import { useTheme } from "@mui/styles";

export const Dashboard = () => {
    const [city, setCity] = useState(localStorage.getItem('city') || '');

    useEffect(() => {
        if (city) {
            localStorage.setItem('city', city);
        }
    }, [city]);

    const onSearchHandler = (city) => {
        if (city) {
            setCity(city);
        }
    };

    const theme = useTheme();
    const currentScheme = theme.colorSchemes[theme.palette.mode];

    return (
        <Box
            sx={{
                backgroundColor: currentScheme.background.default,
                color: currentScheme.text.default,
                padding: '1rem',
                height: '100%',
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                gap: '1rem',
                minHeight:'calc(100vh - 126px - 1rem)'
            }}
        >
            <Search onSearch={onSearchHandler} />
           
            {!city ? (
                <Typography variant='h3' sx={{ fontSize: '2rem', marginTop: '2rem' }}>
                    Find the weather from any city
                </Typography>
            ) : (
                <>
                    <WeatherDetails city={city} />
                    <ForecastPanel city={city} />
                </>
            )}
        </Box>
    );
};

export default Dashboard;

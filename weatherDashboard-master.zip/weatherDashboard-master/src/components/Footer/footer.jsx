import { CopyrightOutlined } from "@mui/icons-material";
import { Typography } from "@mui/material";
import { makeStyles } from "@mui/styles";

const useStyles = makeStyles((theme) => {
    const currentScheme = theme.colorSchemes[theme.palette.mode];
    return {
        footer: {
            backgroundColor: currentScheme.background.secondary,
            color: currentScheme.text.secondary,
            padding: '1rem',
            textAlign: 'center'
        },
    };
});
export const Footer = () => {
    const classes = useStyles();
    return (
        <footer className={classes.footer} >
            <Typography variant="body2" sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>Copy Right<CopyrightOutlined /> MayDay - Matias Videla</Typography>
        </footer>
    )
}
export default Footer;
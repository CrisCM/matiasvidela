import { makeStyles } from "@mui/styles";

const useStyles = makeStyles((theme) => {
    const currentScheme = theme.colorSchemes[theme.palette.mode];

    return {
        customBox: {
            backgroundColor: currentScheme.background.secondary,
            color: currentScheme.text.default, 
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center',
            height:'7rem',
            width:'10rem',
            gap:'10px',
            borderRadius:'6px',
            padding: '1rem',
            fontWeight:'600',
            transition: 'background-color 0.3s ease',
            [theme.breakpoints.down('tablet')]: {
                flexDirection: 'column',
            },
            '&:hover': {
                backgroundColor: currentScheme.background.hover,
            },
        }
    };
});

const CustomBox = ( {title, icon, content }) => {
    const classes = useStyles();

    return (
        <div className={classes.customBox} >
            <span>{title}</span>
            {icon}
            <span>{content}</span>
        </div>
    )
}

export default CustomBox;
import { Air, Speed, Thermostat, Water } from '@mui/icons-material';
import { Box, Grid2, Stack, Typography } from '@mui/material';
import AccordionDetails from '@mui/material/AccordionDetails';
import { useTheme } from '@mui/material/styles';

export const Details = ({ details }) => {
    const theme = useTheme();
    const currentScheme = theme.colorSchemes[theme.palette.mode];
    
    const getHourFormatted = (forec) => {
        return new Date(forec.dt * 1000).toLocaleTimeString('en-EN', {
            hour: '2-digit',
            minute: '2-digit',
            hour12: false
        });
    };

    const boxStyles = {
        border: `1px solid #222`,
        borderRadius: '10px',
        padding: '1rem',
        textAlign: 'center',
        backgroundColor: currentScheme.background.default,
        boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
    };

    const textColor = theme.text.default;

    return (
        <AccordionDetails>
            <Grid2 container spacing={2} columns={{ xs: 4, sm: 8, md: 12 }} justifyContent="center">
                {details.map((forecast) => (
                    <Grid2 key={forecast.dt} xs={12} sm={6} md={4}>
                        <Box sx={boxStyles}>
                            <Typography variant="h6" fontWeight={700} color={textColor}>
                                {getHourFormatted(forecast)}
                            </Typography>

                            <img
                                src={`https://openweathermap.org/img/wn/${forecast.weather[0].icon}@2x.png`}
                                width={60}
                                height={60}
                                alt="Weather icon"
                                onError={(e) => (e.target.style.display = 'none')}
                            />
                            <Typography variant="body1" color={textColor}>
                                {forecast.weather[0]?.description || 'N/A'}
                            </Typography>

                            <Stack alignItems="start" spacing={1}>

                                <Typography variant="body2" sx={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }} color={textColor}>
                                    <Thermostat /> {Math.round(forecast.main.temp)} °C
                                </Typography>

                                <Typography variant="body2" sx={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }} color={textColor}>
                                    <Thermostat /> Min: {Math.round(forecast.main.temp_min)} °C
                                </Typography>

                                <Typography variant="body2" sx={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }} color={textColor}>
                                    <Thermostat /> Max: {Math.round(forecast.main.temp_max)} °C
                                </Typography>

                                <Typography variant="body2" sx={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }} color={textColor}>
                                    <Water /> {forecast.main.humidity} %
                                </Typography>

                                <Typography variant="body2" sx={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }} color={textColor}>
                                    <Thermostat /> Feels: {Math.round(forecast.main.feels_like)} °C
                                </Typography>

                                <Typography variant="body2" sx={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }} color={textColor}>
                                    <Air /> {Math.round(forecast.wind.speed)} km/h
                                </Typography>

                                <Typography variant="body2" sx={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }} color={textColor}>
                                    <Speed /> {Math.round(forecast.main.pressure)} hPa
                                </Typography>
                            </Stack>
                        </Box>
                    </Grid2>
                ))}
            </Grid2>
        </AccordionDetails>
    );
};

export default Details;

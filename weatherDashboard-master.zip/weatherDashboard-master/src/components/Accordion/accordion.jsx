import * as React from 'react';
import Accordion from '@mui/material/Accordion';
import AccordionSummary from '@mui/material/AccordionSummary';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import Details from './accordionDetails';
import { Thermostat } from '@mui/icons-material';
import { Box, Typography } from '@mui/material';

const formatDate = (date) => {
  return new Date(date).toLocaleDateString('en-EN', {
    weekday: 'long',
    day: 'numeric',
  }).toUpperCase();
};

export default function AccordionForecast({ date, forecasts }) {

  const getMinMaxTemps = React.useCallback((forecasts) => {
    const minTemp = Math.round(Math.min(...forecasts.map(forecast => forecast.main.temp_min)));
    const maxTemp = Math.round(Math.max(...forecasts.map(forecast => forecast.main.temp_max)));
    return { minTemp, maxTemp };
  }, [forecasts]);

  const formattedDate = formatDate(date);
  const { minTemp, maxTemp } = getMinMaxTemps(forecasts);

  return (
    <Accordion TransitionProps={{ unmountOnExit: true }}>
      <AccordionSummary
        expandIcon={<ExpandMoreIcon />}
        aria-controls={`${date}-accordion-content`}
        id={`${date}-accordion`}
      >
        <Box sx={{
          width: '100%',
          display: 'flex',
          justifyContent: 'space-evenly',
          alignItems: 'center'
        }}>
          <Typography variant='body2'>{formattedDate}</Typography>
          <Box sx={{ display: 'flex', alignItems: 'center' }}>
            <Thermostat sx={{ marginRight: '0.5rem' }} />
            <Typography>
              <strong>{minTemp}</strong>°C / <strong>{maxTemp}</strong>°C
            </Typography>
          </Box>
        </Box>
      </AccordionSummary>
      <Details details={forecasts} />
    </Accordion>
  )
}
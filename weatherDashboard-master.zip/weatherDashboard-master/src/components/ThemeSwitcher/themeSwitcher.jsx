import { DarkModeOutlined, LightModeOutlined } from '@mui/icons-material';
import { FormControl, InputLabel, MenuItem, Select } from '@mui/material';
import { useColorScheme } from '@mui/material/styles';

export const ModeSwitcher = () => {
    const { mode, setMode } = useColorScheme();

    if (!mode) {
        return null;
    }

    return (
        <FormControl sx={{ m: 1, minWidth: 120 }} size="small">
            <InputLabel id="demo-select-small-label">Theme</InputLabel>
            <Select
                labelId="demo-select-small-label"
                id="demo-select-small"
                value={mode}
                label="Theme"
                onChange={(event) => {
                    setMode(event.target.value);
                }}
            >
                <MenuItem value='dark'><DarkModeOutlined/></MenuItem>
                <MenuItem value='light'><LightModeOutlined/></MenuItem>
            </Select>
        </FormControl>

    );
}
export default ModeSwitcher;
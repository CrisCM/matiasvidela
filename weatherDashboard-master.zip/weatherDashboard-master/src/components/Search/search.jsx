import { Autocomplete, Divider, IconButton, List, ListItem, ListItemButton, TextField, Typography } from "@mui/material";
import { useContext, useState } from "react";
import { SearchContext } from "../../SearchProvider";
import { useCitiesList } from "../../customHooks";
import Loader from "../Loader/Loader";
import { CloseOutlined } from "@mui/icons-material";

const Search = ({ onSearch }) => {
    const [city, setCity] = useState(localStorage.getItem('city') || '');
    const { searchHistory, addToHistory, removeFromHistory } = useContext(SearchContext);
    const { data, isError, isLoading } = useCitiesList();

    if (isError) return <Typography variant="h3">Error Loading Cities</Typography>
    if (isLoading) return <Loader />

    const onSubmitHandler = (valueToSubmit) => {
        if (valueToSubmit.trim()) {
            addToHistory(valueToSubmit);
            onSearch(valueToSubmit);
        }
    };

    const handleKeyDown = (event) => {
        if (event.key === 'Enter') {
            event.preventDefault();
            onSubmitHandler(city);
        }
    };

    const handleOptionSelect = (event, newValue) => {
        if (newValue) {
            setCity(newValue);
            onSubmitHandler(newValue);
        }
    };

    const handleHistoryClick = (historyItem) => {
        setCity(historyItem);
        onSubmitHandler(historyItem);
    };

    const handleRemoveFromHistory = (historyItem) => {
        removeFromHistory(historyItem)
    }
    return (
        <div>
            <form onSubmit={(event) => event.preventDefault()}>
                <Autocomplete
                    freeSolo
                    value={city}
                    onChange={handleOptionSelect}
                    inputValue={city}
                    onInputChange={(event, newInputValue) => setCity(newInputValue)}
                    id="searchInputCity"
                    options={data || []}
                    sx={{ width: 300 }}
                    renderInput={(params) => (
                        <TextField
                            {...params}
                            label="Search"
                            onKeyDown={handleKeyDown}
                        />
                    )}
                />
                {
                    searchHistory.length > 0 &&
                    <>

                        <Divider sx={{ margin: '10px 0' }} />
                        <Typography variant="h6">Recent Searches</Typography>
                        <List>
                            {searchHistory.slice(0, 5).map((historyItem, index) => (
                                <ListItem key={index} secondaryAction={
                                    <IconButton edge="end" aria-label="delete" onClick={() => handleRemoveFromHistory(historyItem)}>
                                        <CloseOutlined />
                                    </IconButton>
                                }>
                                    <ListItemButton onClick={() => handleHistoryClick(historyItem)}>
                                        {historyItem}
                                    </ListItemButton>
                                </ListItem>
                            ))}
                        </List>
                    </>
                }

            </form>

        </div>

    )
}
export default Search;
import { Grid2, Stack, Typography } from "@mui/material";
import CustomBox from "../Box/Box";
import { WbTwilight, Water, Thermostat, Air, Speed, Nightlight } from '@mui/icons-material';
import { useFetchCountry, useWeather } from "../../customHooks";
import Loader from "../Loader/Loader";

const WeatherDetails = ({ city }) => {
    const { weatherInfo, isLoading, isError } = useWeather(city);
    const country = useFetchCountry(weatherInfo);

    if (isLoading) return <Loader />;

    if (isError) {
        return (
            <Typography variant='h3' sx={{ fontSize: '2rem', marginTop: '2rem', color: (theme) => theme.colorSchemes[theme.palette.mode].text.default }}>
                City not found
            </Typography>
        );
    }

    const { sys, main, weather, wind } = weatherInfo || {};

    return (
        <>
            <Typography variant="h1" sx={{ fontSize: '2rem' }}>
                {weatherInfo.name} - {country}
            </Typography>
            <img loading="lazy" src={`https://openweathermap.org/img/wn/${weather[0].icon}@2x.png`} alt="Weather icon" />
            <Stack spacing={2} direction="column" alignItems="center">
                <Typography variant="h6">{Math.round(main.temp)} °C</Typography>
                <Typography variant='body2'>{weather[0].description}</Typography>
                <div>
                    <Typography variant='body2'>{`Max: ${Math.round(main.temp_max)} °C`}</Typography>
                    <Typography variant='body2'>{`Min: ${Math.round(main.temp_min)} °C`}</Typography>
                </div>
            </Stack>
            <Grid2 container spacing={2} columns={{ xs: 2, sm: 3, md: 3 }} justifyContent="center">
                <CustomBox title="FEELS LIKE" icon={<Thermostat />} content={`${Math.round(main.feels_like)} °C`} />
                <CustomBox title="WIND" icon={<Air />} content={`${Math.round(wind.speed)} km/h`} />
                <CustomBox title="HUMIDITY" icon={<Water />} content={`${main.humidity} %`} />
                <CustomBox title="SUNRISE" icon={<WbTwilight />} content={sys.sunrise} />
                <CustomBox title="SUNSET" icon={<Nightlight />} content={sys.sunset} />
                <CustomBox title="PRESSURE" icon={<Speed />} content={`${Math.round(main.pressure)} hPa`} />
            </Grid2>
        </>
    );
};

export default WeatherDetails;

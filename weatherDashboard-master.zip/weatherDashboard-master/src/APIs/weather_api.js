import {
    BASE_URL,
    API_KEY,
    PROXY_URL,
    COUNTRIES_url,
    BASE_URL_FORECAST,
    GET_CITIES_BY_COUNTRY,
} from '../constants';
import {
    getAllCities,
    getForecastPerDay,
    transformData,
} from '../utils';

//https://cors-anywhere.herokuapp.com/corsdemo

/*Get weather for specific city*/
export const getWeatherByCity = async (city) => {
    const url = `${PROXY_URL}${BASE_URL}${city}&appid=${API_KEY}&units=metric`;
    const response = await fetch(url, {
        method: 'GET',
        headers: {
            'Access-Control-Allow-Origin': '*',
            'Content-Type': 'application/json',
        },
    });
    if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
    }

    const data = await response.json();
    return transformData(data);
};

/*Get future forecast for specific city, splitted by 3 hours interval*/
export const getForecast = async (city) => {
    const url = `${PROXY_URL}${BASE_URL_FORECAST}${city}&appid=${API_KEY}&units=metric&cnt=40`;
    const response = await fetch(url, {
        method: 'GET',
        headers: {
            'Access-Control-Allow-Origin': '*',
            'Content-Type': 'application/json',
        },
    });
    if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
    }

    const data = await response.json();
    return getForecastPerDay(data);
};

/*Return full country name with Country Code */
export const getCountryByCode = async (countryCode) => {
    const url = `${COUNTRIES_url}${countryCode}`;

    const response = await fetch(url, {
        method: 'GET',
        headers: {
            'Access-Control-Allow-Origin': '*',
            'Content-Type': 'application/json',
        },
    });
    if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
    }

    const data = await response.json();
    const countryName = data[0]?.name.common;
    return countryName;
};

export const getCitiesList = async () => {
    const url = `${GET_CITIES_BY_COUNTRY}`;
    const country = 'Argentina';

    const response = await fetch(url, {
        method: 'POST',
        body: JSON.stringify({
            country: country,
        }),
        headers: {
            'Access-Control-Allow-Origin': '*',
            'Content-Type': 'application/json',
        },
    });
    if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
    }

    const data = await response.json();
    return getAllCities(data.data);
};

import React, { createContext, useState } from 'react';

export const SearchContext = createContext();

export const SearchProvider = ({ children }) => {
    const [searchHistory, setSearchHistory] = useState([]);

    const addToHistory = (city) => {
        setSearchHistory((prevHistory) => {
            const newHistory = [city, ...prevHistory];
            return newHistory.slice(0, 5);
        });
    };

    const removeFromHistory = (item) => {
        setSearchHistory((prevHistory) => prevHistory.filter((historyItem) => historyItem !== item));
    };
    
    return (
        <SearchContext.Provider value={{ searchHistory, addToHistory, removeFromHistory}}>
            {children}
        </SearchContext.Provider>
    );
};
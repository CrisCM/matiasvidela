import { useEffect, useState } from "react";
import { getCitiesList, getCountryByCode, getForecast, getWeatherByCity } from "./APIs/weather_api";
import useSWR from 'swr';

export const useFetchCountry = (weatherInfo) => {
    const [country, setCountry] = useState('');

    useEffect(() => {
        const fetchCountry = async () => {
            if (weatherInfo?.sys?.country) {
                try {
                    const countryData = await getCountryByCode(weatherInfo.sys.country);
                    setCountry(countryData);
                } catch (error) {
                    console.error("Error fetching country data:", error);
                }
            }
        };

        fetchCountry();
    }, [weatherInfo]);

    return country;
};

export const useWeather = (city) => {
    const { data, error } = useSWR(city ? `weather/?q=${city}` : null, getWeatherByCity, {
        keepPreviousData: true,
        shouldRetryOnError: false,
        errorRetryCount: 0,
        refreshInterval: 0,
        revalidateOnFocus: false,
        revalidateOnReconnect: false,
    });

    return {
        weatherInfo: data,
        isLoading: !error && !data,
        isError: error
    };
};

export const useForecast = (city) => {
    const { data, error } = useSWR(city ? `forecast/?q=${city}` : null, getForecast, {
        keepPreviousData: true,
        shouldRetryOnError: false,
        errorRetryCount: 0,
        refreshInterval: 0,
        revalidateOnFocus: false,
        revalidateOnReconnect: false,
    });

    return {
        forecast: data,
        isLoading: !error && !data,
        isError: error
    };
}

export const useCitiesList = () => {
    const { data, error } = useSWR('/countries/cities', getCitiesList, {
        keepPreviousData: true,
        shouldRetryOnError: false,
        errorRetryCount: 0,
        refreshInterval: 0,
        revalidateOnFocus: false,
        revalidateOnReconnect: false,
    });

    return {
        data,
        isLoading: !error && !data,
        isError: error
    };
}